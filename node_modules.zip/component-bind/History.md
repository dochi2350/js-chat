
1.0.0 / 2014-05-27
==================

  * index: use slice ref (#7, @viatropos)
  * package: rename package to "component-bind"
  * package: add "repository" field (#6, @repoify)
  * package: add "component" section

0.0.1 / 2010-01-03
==================

  * Initial release
